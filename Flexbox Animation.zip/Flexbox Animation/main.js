function Redirect(){
		window.location="http://www.google.com";
	}